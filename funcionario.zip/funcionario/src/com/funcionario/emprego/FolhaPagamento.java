package com.funcionario.emprego;

public class FolhaPagamento {
	private Long cpf;
	private Salario salarios;

	public Long getCpf() {
		return cpf;
	}

	public void setCpf(Long cpf) {
		this.cpf = cpf;
	}

	public Salario getSalarios() {
		return salarios;
	}

	public void setSalarios(Salario salarios) {
		this.salarios = salarios;
	}

}
